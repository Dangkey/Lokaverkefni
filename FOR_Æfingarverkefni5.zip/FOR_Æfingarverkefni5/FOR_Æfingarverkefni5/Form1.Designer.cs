﻿namespace FOR_Æfingarverkefni5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listView1 = new System.Windows.Forms.ListView();
            this.kennitala = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.nafn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.netfang = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.simanumer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbkennitala = new System.Windows.Forms.TextBox();
            this.tbnafn = new System.Windows.Forms.TextBox();
            this.tbnetfang = new System.Windows.Forms.TextBox();
            this.tbsimanumer = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.kennitala,
            this.nafn,
            this.netfang,
            this.simanumer});
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(12, 12);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(592, 248);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // kennitala
            // 
            this.kennitala.Text = "Kennitala";
            this.kennitala.Width = 159;
            // 
            // nafn
            // 
            this.nafn.Text = "Nafn";
            this.nafn.Width = 147;
            // 
            // netfang
            // 
            this.netfang.Text = "Netfang";
            this.netfang.Width = 139;
            // 
            // simanumer
            // 
            this.simanumer.Text = "Símanúmer";
            this.simanumer.Width = 143;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 272);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Kennitala:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 301);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nafn:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 330);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Netfang:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 360);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Símanúmer:";
            // 
            // tbkennitala
            // 
            this.tbkennitala.Location = new System.Drawing.Point(90, 269);
            this.tbkennitala.Name = "tbkennitala";
            this.tbkennitala.Size = new System.Drawing.Size(100, 20);
            this.tbkennitala.TabIndex = 5;
            // 
            // tbnafn
            // 
            this.tbnafn.Location = new System.Drawing.Point(90, 298);
            this.tbnafn.Name = "tbnafn";
            this.tbnafn.Size = new System.Drawing.Size(100, 20);
            this.tbnafn.TabIndex = 6;
            // 
            // tbnetfang
            // 
            this.tbnetfang.Location = new System.Drawing.Point(90, 327);
            this.tbnetfang.Name = "tbnetfang";
            this.tbnetfang.Size = new System.Drawing.Size(100, 20);
            this.tbnetfang.TabIndex = 7;
            // 
            // tbsimanumer
            // 
            this.tbsimanumer.Location = new System.Drawing.Point(90, 357);
            this.tbsimanumer.Name = "tbsimanumer";
            this.tbsimanumer.Size = new System.Drawing.Size(100, 20);
            this.tbsimanumer.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 402);
            this.Controls.Add(this.tbsimanumer);
            this.Controls.Add(this.tbnetfang);
            this.Controls.Add(this.tbnafn);
            this.Controls.Add(this.tbkennitala);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader kennitala;
        private System.Windows.Forms.ColumnHeader nafn;
        private System.Windows.Forms.ColumnHeader netfang;
        private System.Windows.Forms.ColumnHeader simanumer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbkennitala;
        private System.Windows.Forms.TextBox tbnafn;
        private System.Windows.Forms.TextBox tbnetfang;
        private System.Windows.Forms.TextBox tbsimanumer;
    }
}

