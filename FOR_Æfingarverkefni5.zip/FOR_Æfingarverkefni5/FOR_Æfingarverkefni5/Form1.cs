﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FOR_Æfingarverkefni5
{
    public partial class Form1 : Form
    {
        Gagnagrunnur gagnagrunnur = new Gagnagrunnur();
        public Form1()
        {
            InitializeComponent();

            try
            {
                gagnagrunnur.TengingVidGagnagrunn();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*Þetta eru dálkarnir sem eru efst í listViewinu*/
            listView1.Columns.Add("Kennitala", 100);
            listView1.Columns.Add("Nafn", 180);
            listView1.Columns.Add("Netfang", 100);
            listView1.Columns.Add("Símanúmer", 80);


            /*Þetta er listinn sem lesinn er upp úr gagnagrunninum*/
            List<string> linur = new List<string>();

            /*Þetta er arrayin sem er notaður til þess að bæta inn í listviewið*/
            string[] arr = new string[4];

            /*Þetta heldur utam um itemin sem eru bætt við í hverja línu í listviewinu*/
            ListViewItem itm;


            try
            {
                linur = gagnagrunnur.LesautSQLToflu();

                foreach (string lin in linur)
                {
                    /*Hérna er verið að splitta upp línunu sem kemur frá grunninum*/
                    string[] linaUrLista = lin.Split(':');
                    string kt = linaUrLista[0];
                    string nafn = linaUrLista[1];
                    string netfang = linaUrLista[2];
                    string simanumer = linaUrLista[3];

                    /*Hefði líka verið hægt að gera þetta svona arr[0] = linaUrlista[0]*/
                    arr[0] = kt;
                    arr[1] = nafn;
                    arr[2] = netfang;
                    arr[3] = simanumer;

                    /*sett inn í ListViewItemið og bætt svo inn í listView-ið*/
                    itm = new ListViewItem(arr);
                    listView1.Items.Add(itm);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedIndices.Count <= 0)
            {
                return;
            }
            int intSelectIndex = listView1.SelectedIndices[0];
            if (intSelectIndex >= 0)
            {

                tbkennitala.Text = listView1.SelectedItems[0].SubItems[0].Text;
                tbnafn.Text = listView1.SelectedItems[0].SubItems[1].Text;
                tbnetfang.Text = listView1.SelectedItems[0].SubItems[2].Text;
                tbsimanumer.Text = listView1.SelectedItems[0].SubItems[3].Text;
            }



        }




    }


}

